package main;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {
    
    private Message message;

    @BeforeEach
    public void setUp() {
        message = new Message();
    }

    @Test
    public void testCheckMessageLengthSuccess() {
        String testMsg = "Hi Mike, can you join us for dinner tonight?";
        String expected = "Message ready to send.";
        String actual = message.checkMessageLength(testMsg);
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckMessageLengthFailure() {
        // Using literalLong to test a message exceeding 250 characters
        String literalLong = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.";
        
        String actual = message.checkMessageLength(literalLong);
        assertTrue(actual.contains("exceeds 250 characters"));
    }

    @Test
    public void testCheckRecipientCellValid() {
        String validCell = "+27718693002";
        String expected = "Cell phone number successfully captured.";
        String actual = message.checkRecipientCell(validCell);
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckRecipientCellInvalid() {
        String invalidCell = "08575975889";
        String actual = message.checkRecipientCell(invalidCell);
        assertTrue(actual.contains("incorrectly formatted"));
    }

    @Test
    public void testCreateMessageHash() {
        String msgID = "1234567890";
        int messageNum = 0;
        String text = "Hi tonight";
        
        String expected = "12:0:HITONIGHT";
        String actual = message.createMessageHash(msgID, messageNum, text);
        assertEquals(expected, actual);
    }

    @Test
    public void testSentMessageActionSend() {
        String expected = "Message successfully sent.";
        String actual = message.SentMessage(1);
        assertEquals(expected, actual);
    }

    @Test
    public void testSentMessageActionDiscard() {
        String expected = "Press 0 to delete the message.";
        String actual = message.SentMessage(2);
        assertEquals(expected, actual);
    }

    @Test
    public void testSentMessageActionStore() {
        String expected = "Message successfully stored.";
        String actual = message.SentMessage(3);
        assertEquals(expected, actual);
    }
}