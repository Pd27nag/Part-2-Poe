package main;

import java.util.Random;

public class Message {
    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;
    private static int totalMessagesSent = 0;

    // Generates a random 10-digit message ID
    public String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    // Checks if message ID is no more than 10 characters
    public boolean checkMessageID(String id) {
        return id != null && id.length() <= 10;
    }

    // Validates recipient cell number
    public String checkRecipientCell(String cellPhone) {
        if (cellPhone == null || !cellPhone.startsWith("+")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        String numberPart = cellPhone.substring(3);
        if (!numberPart.isEmpty() && numberPart.length() <= 10 && numberPart.matches("\\d+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Checks if message is within the 250 character limit
    public String checkMessageLength(String message) {
        if (message != null && message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message != null ? message.length() - 250 : 0;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // Autogenerates the message hash
    public String createMessageHash(String id, int messageNum, String text) {
        String prefix = (id != null && id.length() >= 2) ? id.substring(0, 2) : "00";
        String cleanText = text != null ? text.trim() : "";
        String[] words = cleanText.split("\\s+");
        String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
        String lastWord = words.length > 1 ? words[words.length - 1].toUpperCase() : firstWord;
        
        return prefix + ":" + messageNum + ":" + firstWord + lastWord;
    }

    // Handles user action choices (1: Send, 2: Discard, 3: Store)
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }
}