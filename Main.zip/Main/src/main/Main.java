package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login userLogin = new Login();

        System.out.println("=== REGISTRATION ===");

        System.out.println("Enter first name:");
        userLogin.setFirstName(input.nextLine());

        System.out.println("Enter last name:");
        userLogin.setLastName(input.nextLine());

        String username;
        while (true) {
            System.out.println("Enter username:");
            username = input.nextLine();

            if (userLogin.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password;
        while (true) {
            System.out.println("Enter password:");
            password = input.nextLine();

            if (userLogin.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cellPhone;
        while (true) {
            System.out.println("Enter cell phone number (e.g. +27838968976):");
            cellPhone = input.nextLine();

            if (userLogin.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        }

        System.out.println(userLogin.registerUser(username, password));

        System.out.println("\n=== LOGIN ===");

        while (true) {
            System.out.println("Enter username:");
            String enteredUsername = input.nextLine();

            System.out.println("Enter password:");
            String enteredPassword = input.nextLine();

            boolean loginSuccess = userLogin.loginUser(enteredUsername, enteredPassword);
            System.out.println(userLogin.returnLoginStatus(loginSuccess));

            if (loginSuccess) {
                // Welcome Banner for Part 2 
                System.out.println("Welcome to QuickChat.");
                
                boolean running = true;
                while (running) {
                    System.out.println("\n--- QuickChat Menu ---");
                    System.out.println("1. Send Messages");
                    System.out.println("2. Show recently sent messages");
                    System.out.println("3. Quit");
                    System.out.print("Choose an option: ");
                    
                    int menuChoice = Integer.parseInt(input.nextLine());

                    switch (menuChoice) {
                        case 1:
                            System.out.print("How many messages would you like to send? ");
                            int numMessages = Integer.parseInt(input.nextLine());

                            for (int i = 0; i < numMessages; i++) {
                                Message msg = new Message();
                                String msgID = msg.generateMessageID();
                                
                                // Recipient Validation Loop
                                String recipient;
                                while (true) {
                                    System.out.print("Enter recipient cell number (e.g., +27...): ");
                                    recipient = input.nextLine();
                                    String cellResult = msg.checkRecipientCell(recipient);
                                    System.out.println(cellResult);
                                    if (cellResult.contains("successfully")) {
                                        break;
                                    }
                                }

                                // Message Length Validation Loop
                                String messageText;
                                while (true) {
                                    System.out.print("Enter your message (max 250 characters): ");
                                    messageText = input.nextLine();
                                    String lengthCheck = msg.checkMessageLength(messageText);
                                    System.out.println(lengthCheck);
                                    if (lengthCheck.equals("Message ready to send.")) {
                                        break;
                                    }
                                }

                                // Generate Hash & ID details
                                String hash = msg.createMessageHash(msgID, i, messageText);
                                System.out.println("Message ID generated: " + msgID);
                                System.out.println("Message Hash: " + hash);

                                // Action Selection Menu
                                System.out.println("Choose action:\n1) Send Message\n2) Discard Message\n3) Store Message");
                                int actionChoice = Integer.parseInt(input.nextLine());
                                String resultMessage = msg.SentMessage(actionChoice);
                                System.out.println(resultMessage);
                            }

                            System.out.println("Total messages sent: " + Message.returnTotalMessages());
                            break;

                        case 2:
                            System.out.println("Coming Soon.");
                            break;

                        case 3:
                            running = false;
                            System.out.println("Exiting QuickChat. Goodbye!");
                            break;

                        default:
                            System.out.println("Invalid choice, please select 1, 2, or 3.");
                    }
                }
                break;
            }
        }
        
        input.close();
    }
}